void main()
{

   int a;
   int b;

   a = 0;
   b = 100;
   b = a + b;

   return 0;
}
