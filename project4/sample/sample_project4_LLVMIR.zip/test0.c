void main()
{

   int a;


   a = 2;

}
