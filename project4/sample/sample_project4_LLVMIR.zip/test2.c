void main()
{
   int a;
   int b;

   a = 0;
   b = a + 100 + 123;
}
