int main(void)
{
   int a, b;
   a = 1;
   b = a + 4;
   printf("%d\n", b);
   return 0;
}
