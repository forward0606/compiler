int a;
int main(void)
{
   a = 1;
   return 0;
}
