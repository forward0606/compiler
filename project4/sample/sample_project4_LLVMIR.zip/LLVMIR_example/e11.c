int main()
{
   int a;
   int b;
   
   a = 1;
   if (a > 0)
      b = 0;
   else
      b = a + 2;
}

