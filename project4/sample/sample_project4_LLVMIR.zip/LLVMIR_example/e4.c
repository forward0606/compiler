int main(void)
{
   int a, b;
   a = 1;
   b = a + 4;
   return 0;
}
