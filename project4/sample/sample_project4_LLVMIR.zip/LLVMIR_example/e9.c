int func(void)
{
   int a;
   a = 10;
   return a;
}

int main(void)
{
   int b;

   b = func();
   return 0;
}
