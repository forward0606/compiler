int func(int a)
{
   return a+1;
}

int main(void)
{
   int b;

   b = func(2);
   return 0;
}
