int a, b;
int main(void)
{
   a = 1;
   b = a + 4;
   return 0;
}
