int main()
{
   int a;
   int b;
   
   a = 1;
   b = a + 2;
   printf("%d\n", b);
}

