int nums[3] = {1, 2, 3};

int main(void)
{
    int a;
    a = nums[2];

    return 0;
}
